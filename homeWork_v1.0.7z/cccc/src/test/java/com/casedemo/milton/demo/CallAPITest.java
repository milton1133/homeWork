package com.casedemo.milton.demo;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.casedemo.milton.demo.controller.CoinDeskController;
import com.casedemo.milton.demo.util.CallAPI;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CallAPITest {

	@Autowired
	private CallAPI callApi;
	
	// 呼叫 coindesk 的 API。
	@Test
	public void test() {
		System.err.println(callApi.callAPI());
	}

	// A. 更新時間（時間格式範例：1990/01/01 00:00:00）。
	@Test
	public void dateFormatTest() {
		System.err.println(callApi.fromatInputDate());
	}

	// B. 幣別相關資訊（幣別，幣別中文名稱，以及匯率）。
	@Test
	public void coinToChinese() {
		System.err.println(callApi.coinToChinese());
	}
	
	

}
