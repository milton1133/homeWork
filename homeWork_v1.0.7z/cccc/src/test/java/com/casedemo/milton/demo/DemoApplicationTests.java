package com.casedemo.milton.demo;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {

	@Test
	void contextLoads() {
	}

	@Autowired
	private DataSource dataSource;

	/**
	 * 測試連接數據庫
	 * 
	 * @throws SQLException
	 */
	@Test
	public void testConn() throws SQLException {
		Connection conn = dataSource.getConnection();
		System.err.println(conn);

	}

}
