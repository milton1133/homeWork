package com.casedemo.milton.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.casedemo.milton.demo.controller.CoinDeskController;
import com.casedemo.milton.demo.dao.CoinDao;
import com.casedemo.milton.demo.entity.CoinBean;
import com.casedemo.milton.demo.util.CallAPI;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CoinCRUD {
	
	@Autowired
	private CallAPI callApi;
	
	@Autowired
	private CoinDeskController coinDeskController;
	//試呼叫查詢幣別對應表資料 API，並顯示其內容。
	@Test
	public void findAll() {
		System.err.println(coinDeskController.findAll());
	}
	//試呼叫新增幣別對應表資料 API。
	@Test
	public void insert() {
		System.err.println(coinDeskController.insert());
	}
	//測試呼叫刪除幣別對應表資料 API。
	@Test
	public void delete() {
		System.err.println(coinDeskController.delete());
	}
	//測試根據Id呼叫刪除幣別對應表資料 API。
	@Test
	public void deleteById() {
		System.err.println(coinDeskController.deleteById());
	}
	//測試呼叫更新幣別對應表資料 API，並顯示其內容。
	@Test
	public void update() {
		System.err.println(coinDeskController.update());
	}

}
