package com.casedemo.milton.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor

public class CoinBean {

	@Id
	private long id;
	private String code;
	private String name;

	public CoinBean() {

	}

	public CoinBean(Long id, String code, String name) {
		this.id = id;
		this.code = code;
		this.name = name;
	}

}
