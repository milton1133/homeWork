package com.casedemo.milton.demo.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import org.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CallAPI {

	public String callAPI() {
		String url = "https://api.coindesk.com/v1/bpi/currentprice.json";
		RestTemplate restTemplate = new RestTemplate();
		Map<String, Object> submap = new HashMap<String, Object>();

		// 方式一：GET 方式獲取 JSON 串數據
		String result = restTemplate.getForObject(url, String.class);
		System.out.println("get_product1返回結果：" + result);

		return result;

	}

	public Map<String, Object> fromatInputDate() {

		try {
			String APIdata = callAPI();
			System.out.println("有抓到API");

			JSONObject jsonObject = new JSONObject(APIdata);
			String updated = jsonObject.getJSONObject("time").getString("updated").toString();
			String updatedISO = jsonObject.getJSONObject("time").getString("updatedISO").toString();
			String updateduk = jsonObject.getJSONObject("time").getString("updateduk").toString();

			Map<String, Object> submap = new HashMap<String, Object>();
			Map<String, Object> map = new HashMap<String, Object>();

			submap.put("updated", updatedToDateStr(updated));
			submap.put("updatedISO", updatedISOToDateStr(updatedISO));
			submap.put("updateduk", updatedukToDateStr(updateduk));

			map = submap;
			return map;

		} catch (Exception e) {

		}
		return null;

	}

	public static String updatedToDateStr(String utcTime) {
		
		//Locale.TAIWAN -> 要用Locale.ENGLISH 才不會報錯
		SimpleDateFormat sf = new SimpleDateFormat("MMM d, yyyy HH:mm:ss 'UTC'", Locale.ENGLISH);
		
//		SimpleDateFormat sf = new SimpleDateFormat("'Nov' dd','yyyy HH:mm:ss 'UTC'", Locale.TAIWAN);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		TimeZone utcZone = TimeZone.getTimeZone("UTC");
		sf.setTimeZone(utcZone);
		Date date = null;
		String dateTime = "";
		try {
			System.out.println("updated原始時間" + utcTime);
			
			//先進行型別轉換 String -> Date
			date = sf.parse(utcTime);
			System.out.println("updated轉成Date型別:" + date);
			
			//Date -> String 一定用用Date型別 才能轉換成自己想要的格式
			dateTime = sdf.format(date);
			System.out.println("updated轉換後:" + dateTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateTime;
	}

	public static String updatedISOToDateStr(String utcTime) {
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.ENGLISH);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		TimeZone utcZone = TimeZone.getTimeZone("UTC");
		sf.setTimeZone(utcZone);
		Date date = null;
		String dateTime = "";
		try {
			
			System.out.println("------------------------------");
			System.out.println("updatedISO原始時間:" + utcTime);
			
			date = sf.parse(utcTime);
			System.out.println("updatedISO轉成Date型別:" + date);
			
			dateTime = sdf.format(date);
			System.out.println("updatedISO轉換後:" + dateTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateTime;
	}

	public static String updatedukToDateStr(String utcTime) {
		SimpleDateFormat sf = new SimpleDateFormat("MMM d',' yyyy 'at' HH:mm 'GMT'", Locale.ENGLISH);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		TimeZone utcZone = TimeZone.getTimeZone("UTC");
		sf.setTimeZone(utcZone);
		Date date = null;
		String dateTime = "";
		try {
			System.out.println("------------------------------");
			System.out.println("updatedukTo原始時間:" + utcTime);
			
			date = sf.parse(utcTime);
			System.out.println("updatedukTo轉成Date型別:" + date);
			
			dateTime = sdf.format(date);
			System.out.println("updatedukTo轉換後:" + dateTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateTime;
	}

	public List<Map<String, Object>> coinToChinese() {

		String APIdata = callAPI();
		JSONObject jsonObject = new JSONObject(APIdata);
		String coinUSD = jsonObject.getJSONObject("bpi").getJSONObject("USD").getString("code").toString();
		String rate_float_USD = jsonObject.getJSONObject("bpi").getJSONObject("USD").getString("rate").toString();

		String coinGBP = jsonObject.getJSONObject("bpi").getJSONObject("GBP").getString("code").toString();
		String rate_float_GBP = jsonObject.getJSONObject("bpi").getJSONObject("GBP").getString("rate").toString();

		String coinEUR = jsonObject.getJSONObject("bpi").getJSONObject("EUR").getString("code").toString();
		String rate_float_EUR = jsonObject.getJSONObject("bpi").getJSONObject("EUR").getString("rate").toString();

		System.out.println("coinUSD:" + coinUSD);
		System.out.println("rate_float_USD:" + rate_float_USD);

		Map<String, Object> submap = new HashMap<String, Object>();
		Map<String, Object> map = new HashMap<String, Object>();
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		submap.put("code", coinUSD);
		submap.put("name", "美金");
		submap.put("rate", rate_float_USD);
		list.add(submap);

		submap.put("code", coinGBP);
		submap.put("name", "英鎊");
		submap.put("rate", rate_float_GBP);
		list.add(submap);

		submap.put("code", coinEUR);
		submap.put("name", "歐元");
		submap.put("rate", rate_float_EUR);
		list.add(submap);

		return list;
	}

	public static void main(String[] args) throws ParseException {
		
		
		CallAPI a = new CallAPI();
		
//		SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d, yyyy h:m:s aa", Locale.ENGLISH);
//		Date date = dateFormat.parse("Aug 28, 2015 6:8:30 PM");
//		
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
//		String date2 = sdf.format(date);
//		System.out.println(date2);
		
		System.out.println(a.fromatInputDate());
	}

}
