package com.casedemo.milton.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.casedemo.milton.demo.entity.CoinBean;

@Repository
public interface CoinDao  extends JpaRepository<CoinBean, Long> {
	
}


