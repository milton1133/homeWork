package com.casedemo.milton.demo;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.casedemo.milton.demo.dao.CoinDao;
import com.casedemo.milton.demo.entity.CoinBean;

@SpringBootApplication
@EnableConfigurationProperties
@Configuration
public class DemoApplication {

	@Bean
    InitializingBean InitData(CoinDao coinDao){
        return ()->{                   
        	coinDao.save(new CoinBean(1,"USD","美金"));
        	coinDao.save(new CoinBean(2,"GBP","英鎊"));
        	coinDao.save(new CoinBean(3,"TWD","台幣"));
        };
	}
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}
