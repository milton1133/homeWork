package util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.client.RestTemplate;
import com.alibaba.fastjson.JSONObject;

import net.sf.json.JSONSerializer;

public class ExternalUtil{
	
	
	public String coindeskAPI() {
		
		String url = "https://api.coindesk.com/v1/bpi/currentprice.json";		
		RestTemplate restTemplate=new RestTemplate();
		Map<String, Object> submap = new HashMap<String, Object>();
		
		//方式一：GET 方式獲取 JSON 串數據
		String result = restTemplate.getForObject(url, String.class);
		System.out.println("get_product1返回結果：" + result);
		
		JSONObject json = (JSONObject) JSONSerializer.toJSON(result);
		

		
		submap.put("time",json.get("time"));
//		JSONObject json = JSONObject.fromObject(result); //得到整個json串
//		JSONObject json = new JSONObject();
		
		//方式二：GET 方式獲取 JSON 數據映射後的 Product 實體對象
//		ResponesVo vo = restTemplate.getForObject(url, ResponesVo.class);
//		System.out.println("get_product1返回結果：" + vo);
		
		//方式三：GET 方式獲取包含 Product 實體對象 的響應實體 ResponseEntity 對象,用 getBody() 獲取
//		ResponseEntity<ResponesVo> responseEntity = restTemplate.getForEntity(url, ResponesVo.class);
//		System.out.println("get_product1返回結果：" + responseEntity);
		
		return result;
	}
	
	public void get() {
		
	}
	
	
	
	public static void main(String[] args) {
		
		ExternalUtil a = new ExternalUtil();
		
		a.coindeskAPI();
	}
	
	
}
