package test;

import java.util.HashMap;
import java.util.Map;

public class TennisGame {

	static int  AplayerScoreTimes = 0;
	//static String AplayerScore = "";
		
	public static String score(Object newParam) {
		Map<Integer,String> AplayerScore = new HashMap<Integer,String>();
		AplayerScore.put(0,"love");
		AplayerScore.put(1,"fifteen");
		AplayerScore.put(2,"thirty");
		AplayerScore.put(3,"forty");
		
		String text = "";	
			if(0 == AplayerScoreTimes) {
				text =  AplayerScore.get(AplayerScoreTimes) + " all";
			}else{
			String text1;
				String love = " love";
				text1 =  AplayerScore.get(AplayerScoreTimes) + love;
			text = text1;
			}
		return text;
	}

	public static void main(String[] args) {
		AplayerScoreTimes ++;
		AplayerScoreTimes ++;
		AplayerScoreTimes ++;
		System.out.println(score(null));
		
//		System.out.println(fifteen_love());
	}

}
