package vo;



import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponesVo {
	

	@JsonProperty("FmMsgId") // 轉出型態
	@JSONField(name = "FmMsgId") // 轉入型態
	private String FmMsgId;   
	
	

	

}
