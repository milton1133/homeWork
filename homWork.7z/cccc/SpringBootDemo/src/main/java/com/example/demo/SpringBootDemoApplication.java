package com.example.demo;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import dao.CoinRepository;
import entity.CoinBean;

@SpringBootApplication
public class SpringBootDemoApplication {

	
	@Bean
    InitializingBean saveData(CoinRepository repo){
        return ()->{
            repo.save(new CoinBean("20211115","1","A", "AB"));
            repo.save(new CoinBean("20211115","2","A", "AB"));
            repo.save(new CoinBean("20211115","3","A", "AB"));
            repo.save(new CoinBean("20211115","4","A", "AB"));
        };
    }
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemoApplication.class, args);
	}

	
	
}
