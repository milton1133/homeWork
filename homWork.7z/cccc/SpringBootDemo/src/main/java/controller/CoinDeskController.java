package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import dao.CoinRepository;
import entity.CoinBean;

@Controller
public class CoinDeskController {
	@Autowired
	private CoinRepository coinRepository;

	@ResponseBody
	@RequestMapping("/hello")
	public List<CoinBean> hello() {
		return coinRepository.findAll();
	}
}
