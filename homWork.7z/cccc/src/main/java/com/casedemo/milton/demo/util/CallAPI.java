package com.casedemo.milton.demo.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import org.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CallAPI {

	public String callAPI() {
		String url = "https://api.coindesk.com/v1/bpi/currentprice.json";
		RestTemplate restTemplate = new RestTemplate();
		Map<String, Object> submap = new HashMap<String, Object>();

		// 方式一：GET 方式獲取 JSON 串數據
		String result = restTemplate.getForObject(url, String.class);
		System.out.println("get_product1返回結果：" + result);

		return result;

	}

	public Map<String, Object> fromatInputDate() {

		try {
			String APIdata = callAPI();
			System.out.println("有抓到API");

			JSONObject jsonObject = new JSONObject(APIdata);
			String updated = jsonObject.getJSONObject("time").getString("updated").toString();
			String updatedISO = jsonObject.getJSONObject("time").getString("updatedISO").toString();
			String updateduk = jsonObject.getJSONObject("time").getString("updateduk").toString();

			Map<String, Object> submap = new HashMap<String, Object>();
			Map<String, Object> map = new HashMap<String, Object>();

			submap.put("updated", updatedToDateStr(updated));
			submap.put("updatedISO", updatedISOToDateStr(updatedISO));
			submap.put("updateduk", updatedukToDateStr(updateduk));

			map = submap;
			return map;

		} catch (Exception e) {

		}
		return null;

	}

	public static String updatedToDateStr(String utcTime) {
		SimpleDateFormat sf = new SimpleDateFormat("'Nov' dd','yyyy HH:mm:ss 'UTC'", Locale.TAIWAN);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/11/dd HH:mm:ss");
		TimeZone utcZone = TimeZone.getTimeZone("UTC");
		sf.setTimeZone(utcZone);
		Date date = null;
		String dateTime = "";
		try {
			date = sf.parse(utcTime);
			dateTime = sdf.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateTime;
	}

	public static String updatedISOToDateStr(String utcTime) {
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.TAIWAN);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		TimeZone utcZone = TimeZone.getTimeZone("UTC");
		sf.setTimeZone(utcZone);
		Date date = null;
		String dateTime = "";
		try {
			date = sf.parse(utcTime);
			dateTime = sdf.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateTime;
	}

	public static String updatedukToDateStr(String utcTime) {
		SimpleDateFormat sf = new SimpleDateFormat("'Nov' dd',' yyyy 'at' HH:mm 'GMT'", Locale.TAIWAN);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/11/dd HH:mm:ss");
		TimeZone utcZone = TimeZone.getTimeZone("UTC");
		sf.setTimeZone(utcZone);
		Date date = null;
		String dateTime = "";
		try {
			date = sf.parse(utcTime);
			dateTime = sdf.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateTime;
	}

	public List<Map<String, Object>> coinToChinese() {
		
		
		String APIdata = callAPI();
		JSONObject jsonObject = new JSONObject(APIdata);
		String coinUSD = jsonObject.getJSONObject("bpi").getJSONObject("USD").getString("code").toString();
		String rate_float_USD = jsonObject.getJSONObject("bpi").getJSONObject("USD").getString("rate").toString();
		
		String coinGBP = jsonObject.getJSONObject("bpi").getJSONObject("GBP").getString("code").toString();
		String rate_float_GBP = jsonObject.getJSONObject("bpi").getJSONObject("GBP").getString("rate").toString();
		
		String coinEUR = jsonObject.getJSONObject("bpi").getJSONObject("EUR").getString("code").toString();
		String rate_float_EUR = jsonObject.getJSONObject("bpi").getJSONObject("EUR").getString("rate").toString();
		
		System.out.println("coinUSD:" + coinUSD);
		System.out.println("rate_float_USD:" + rate_float_USD);
		
		Map<String, Object> submap = new HashMap<String, Object>();
		Map<String, Object> map = new HashMap<String, Object>();
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		submap.put("code", coinUSD);
		submap.put("name", "美金");
		submap.put("rate", rate_float_USD);
		list.add(submap);
		
		submap.put("code", coinGBP);
		submap.put("name", "英鎊");
		submap.put("rate", rate_float_GBP);
		list.add(submap);
		
		submap.put("code", coinEUR);
		submap.put("name", "歐元");
		submap.put("rate", rate_float_EUR);	
		list.add(submap);
		
		return list;
	}

	public static void main(String[] args) {

		CallAPI a = new CallAPI();

		System.out.println(a.coinToChinese());
	}

}
