package com.casedemo.milton.demo.dao;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.casedemo.milton.demo.entity.CoinBean;


@RestController
public class CoinDaoImp {
	
	@Autowired
	private CoinDao coindao;
	
	public List<CoinBean> getCoinDesk() {
		
		System.out.println( coindao.findAll());
		return coindao.findAll();
		
		
	}
}
