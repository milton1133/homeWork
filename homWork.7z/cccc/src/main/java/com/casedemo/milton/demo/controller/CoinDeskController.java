package com.casedemo.milton.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.casedemo.milton.demo.dao.CoinDao;
import com.casedemo.milton.demo.entity.CoinBean;

@RestController
public class CoinDeskController{

	@Autowired
	private CoinDao coinDao;

	@ResponseBody
	@RequestMapping("/findAll")
	public List<CoinBean> findAll() {
		return coinDao.findAll();
	}
	
	@ResponseBody
	@RequestMapping("/delete")
	public List<CoinBean> delete() {
		coinDao.deleteAll();
		return coinDao.findAll();
	}
	
	@ResponseBody
	@RequestMapping("/deleteById")
	public List<CoinBean> deleteById() {
		Long id = (long) 1;
		coinDao.deleteById(id);
		return coinDao.findAll();
	}
	
	@ResponseBody
	@RequestMapping("/insert")
	public List<CoinBean> insert() {
		coinDao.save(new CoinBean(4, "JPA", "日幣"));
		return coinDao.findAll();
	}
	
	@ResponseBody
	@RequestMapping("/update")
	public List<CoinBean> update() {
		coinDao.save(new CoinBean(4, "XXX", "日幣"));
		return coinDao.findAll();
	}
}
